This module finish the Latin hypercube sampling from uniform distribution. 

