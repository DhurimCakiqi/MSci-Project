This module contains the codes for precessing the raw data.

`build_data.py` is the main function. 
By running main function, we can get the `dataset.xlsx`  file. It is the datasets we used for training ML models.
